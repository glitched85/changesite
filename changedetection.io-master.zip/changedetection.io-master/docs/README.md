Directory of docs

To regenerate API docs

Run from this directory.

`node_modules/apidoc/bin/apidoc -i ../changedetectionio/api/ -o api_v1`

