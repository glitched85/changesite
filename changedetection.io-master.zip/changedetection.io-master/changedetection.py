#!/usr/bin/env python3

# Only exists for direct CLI usage

import changedetectionio
changedetectionio.main()
